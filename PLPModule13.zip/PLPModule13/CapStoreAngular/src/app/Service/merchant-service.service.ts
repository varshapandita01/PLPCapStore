import { Injectable } from '@angular/core';
import { Merchant } from '../Model/Merchant';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';





@Injectable({
  providedIn: 'root'
})
export class MerchantServiceService {

 

  constructor(private http: HttpClient, private routes: Router) { }

  baseHref = "http://localhost:8880/merchant";

  add(merchant: Merchant) {
    var body = {
      firstName: merchant.firstName,
      lastName: merchant.lastName,
      email: merchant.email,
      password: merchant.password,
      contact: merchant.contact,
      isActive: "yes"
    }
    this.routes.navigate(['/add']);
    return this.http.post<Merchant>(this.baseHref + "/add", body);
  }






  searchMerchant(id: number) {
    this.routes.navigate(['/delete']);
    return this.http.get<Merchant>(`${this.baseHref}/get/${id}`);
  }


  delete(id: number) {
    this.routes.navigate(['/add']);
    return this.http.delete(`${this.baseHref}/delete/${id}`);
  }

  sendInvitation(mobile: number) {
    
    var body = {
     
    }
    
   
    this.routes.navigate(['/add']);
    return this.http.post(`${this.baseHref }/sendSmsInvitation/${mobile}`, body);


  }
}
