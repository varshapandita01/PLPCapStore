import { Component, OnInit } from '@angular/core';
import { MerchantServiceService } from '../Service/merchant-service.service';


@Component({
  selector: 'app-send-invitation',
  templateUrl: './send-invitation.component.html',
  styleUrls: ['./send-invitation.component.css']
})
export class SendInvitationComponent implements OnInit {
  mobile: number
  constructor(private merchantService: MerchantServiceService) {

    
  }

  ngOnInit() {
    this.mobile=0
  }

  send() {

    this.merchantService.sendInvitation(this.mobile).subscribe(
      result => {
        console.log(result)
        console.log("Added Successfully"),alert("Sent Invitation Successfully")
      }, error => { console.log(error),alert("Failed") }
    )
    
    
  
  }
}
