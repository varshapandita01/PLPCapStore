import { Component, OnInit } from '@angular/core';
import { MerchantServiceService } from '../Service/merchant-service.service';

@Component({
  selector: 'app-send-invitation',
  templateUrl: './send-invitation.component.html',
  styleUrls: ['./send-invitation.component.css']
})
export class SendInvitationComponent implements OnInit {
  
  constructor(private merchantService: MerchantServiceService) {

    
  }

  ngOnInit() {
  }

  send() {

    this.merchantService.sendInvitation().subscribe(
      result => {
        console.log(result)
        console.log("Added Successfully"),alert("Sent Innitation Successfully")
      }, error => { console.log(error),alert("Failed") }
    )
    
    
  
  }
}
